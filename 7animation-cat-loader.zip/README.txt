A Pen created at CodePen.io. You can find this one at https://codepen.io/eyesight/pen/WLGaJK.

 Loading animation, inspired by Jake Flemings shot on dribbble: https://dribbble.com/shots/2415798-Kitty-Wiggle-Pt-2